import express from 'express';
import cron from 'node-cron';
import { db } from './db.js';
import { parseCommand } from './ai.js';
import { verifySignature, reply, push } from './line.js';
import { TYPES, compute, insertDoc } from './docs.js';
import { renderDoc, esc } from './render.js';
import { todayBkk, addDays, dayOfWeek, isValidYmd, thaiDate, fmtBaht } from './thai.js';

const ALLOWED = (process.env.ALLOWED_USER_IDS || '').split(',').map((s) => s.trim()).filter(Boolean);
const BASE = process.env.BASE_URL || '';
const OPEN = "status NOT IN ('เสร็จ','ยกเลิก')";
const app = express();

// ---------- LINE webhook ----------
app.post('/webhook', express.raw({ type: '*/*' }), (req, res) => {
  if (!verifySignature(req.body, req.get('x-line-signature'))) return res.sendStatus(401);
  res.sendStatus(200); // ตอบ LINE ทันที แล้วค่อยประมวลผล
  for (const ev of JSON.parse(req.body.toString('utf8')).events || []) {
    if (ev.type !== 'message' || ev.message.type !== 'text') continue;
    handle(ev).catch((e) => { console.error(e); reply(ev.replyToken, '⚠️ ระบบขัดข้อง ลองใหม่อีกครั้ง'); });
  }
});

async function handle(ev) {
  const uid = ev.source.userId, rt = ev.replyToken, text = ev.message.text.trim();
  if (!ALLOWED.length) return reply(rt, `userId ของคุณคือ\n${uid}\nนำไปใส่ ALLOWED_USER_IDS ใน .env แล้วรีสตาร์ท`);
  if (!ALLOWED.includes(uid)) return; // คนอื่นสั่งงานไม่ได้
  if (text === 'ยืนยัน') return confirmPending(uid, rt);
  if (text === 'ยกเลิก') { db.prepare('DELETE FROM pending WHERE user_id=?').run(uid); return reply(rt, 'ยกเลิกแล้ว'); }

  const cmd = await parseCommand(text);
  switch (cmd.intent) {
    case 'create_doc':  return createDoc(uid, rt, cmd);
    case 'convert_doc': return convertDoc(uid, rt, cmd);
    case 'create_job':  return createJob(rt, cmd);
    case 'update_job':  return updateJob(rt, cmd);
    case 'list_jobs':   return reply(rt, jobList());
    default: return reply(rt, HELP);
  }
}

const HELP = `ตัวอย่างคำสั่ง
• ทำใบเสนอราคา คุณสมชาย 081-234-5678 ติดตั้งกล้อง 4 ตัว ตัวละ 3500 ส่วนลด 500 ไม่รวม vat มัดจำ 50%
• ออกใบกำกับภาษีจาก QT181069001
• เพิ่มงาน ติดตั้งกล้องบ้านคุณสมชาย ส่งมอบศุกร์หน้า
• งาน #3 กำลังทำ / งาน #3 เสร็จแล้ว
• งานค้าง`;

// ---------- เอกสาร (ต้องยืนยันก่อนออกเลขที่จริง) ----------
function savePending(uid, payload) {
  db.prepare('INSERT OR REPLACE INTO pending(user_id,payload,created_at) VALUES(?,?,?)').run(uid, JSON.stringify(payload), Date.now());
}

function docSummary(d) {
  const lines = d.items.map((l) => `• ${l.name} ${l.qty} × ${fmtBaht(l.unit_price)} = ${fmtBaht(l.amount)}`).join('\n');
  return `${TYPES[d.type].title} (ยังไม่ออกเลขที่)\nลูกค้า: ${d.customer.name || '-'}\nวันที่: ${thaiDate(d.issue_date, true)}\n${lines}\n` +
    (d.discount ? `ส่วนลด ${fmtBaht(d.discount)}\n` : '') +
    (d.vat_mode !== 'none' ? `VAT 7% ${fmtBaht(d.vat)}\n` : '') +
    `รวมทั้งสิ้น ${fmtBaht(d.total)} บาท\n\nพิมพ์ "ยืนยัน" เพื่อออกเอกสาร หรือ "ยกเลิก"`;
}

function createDoc(uid, rt, cmd) {
  const type = cmd.doc_type;
  const missing = [];
  if (!TYPES[type]) missing.push('ประเภทเอกสาร');
  if (!cmd.customer?.name) missing.push('ชื่อลูกค้า');
  if (!cmd.items?.length) missing.push('รายการสินค้า/บริการ');
  if (missing.length) return reply(rt, 'ขาดข้อมูล: ' + missing.join(', '));

  let vat_mode = cmd.vat_mode || process.env.DEFAULT_VAT_MODE || 'exclusive';
  if (TYPES[type].tax && vat_mode === 'none') vat_mode = 'exclusive'; // เอกสารภาษีต้องมี VAT แยกบรรทัด
  const c = compute({ items: cmd.items, discount: cmd.discount, vat_mode });
  const doc = {
    type, issue_date: todayBkk(), customer: cmd.customer, items: c.lines, discount: c.discount,
    vat_mode, subtotal: c.subtotal, vat: c.vat, total: c.total,
    note: cmd.note, payment_terms: cmd.payment_terms, ref_doc_no: null,
  };
  savePending(uid, { kind: 'doc', doc });
  return reply(rt, docSummary(doc));
}

function convertDoc(uid, rt, cmd) {
  const src = db.prepare('SELECT * FROM documents WHERE doc_no=?').get(String(cmd.from_doc_no || '').toUpperCase());
  if (!src) return reply(rt, 'ไม่พบเอกสารต้นทาง ' + (cmd.from_doc_no || ''));
  if (!TYPES[cmd.doc_type]) return reply(rt, 'ระบุประเภทเอกสารปลายทางด้วย เช่น ใบกำกับภาษี');
  if (TYPES[cmd.doc_type].tax && src.vat_mode === 'none')
    return reply(rt, 'เอกสารต้นทางไม่ได้คิด VAT — ให้สร้างใหม่โดยระบุ VAT ชัดเจน');
  const doc = {
    type: cmd.doc_type, issue_date: todayBkk(), customer: JSON.parse(src.customer), items: JSON.parse(src.items),
    discount: src.discount, vat_mode: src.vat_mode, subtotal: src.subtotal, vat: src.vat, total: src.total,
    note: cmd.note ?? src.note, payment_terms: null, ref_doc_no: src.doc_no,
  };
  savePending(uid, { kind: 'doc', doc });
  return reply(rt, docSummary(doc));
}

function confirmPending(uid, rt) {
  const p = db.prepare('SELECT * FROM pending WHERE user_id=?').get(uid);
  db.prepare('DELETE FROM pending WHERE user_id=?').run(uid);
  if (!p || Date.now() - p.created_at > 15 * 60 * 1000) return reply(rt, 'ไม่มีรายการที่รอยืนยัน (หมดอายุภายใน 15 นาที)');
  const { doc } = JSON.parse(p.payload);
  const row = insertDoc(doc);
  return reply(rt, `✅ ออก${TYPES[row.type].title} เลขที่ ${row.doc_no} แล้ว\n${BASE}/d/${row.token}`);
}

// ---------- งาน ----------
const dateWarn = (ymd) => {
  const h = db.prepare('SELECT name FROM holidays WHERE date=?').get(ymd);
  const dow = dayOfWeek(ymd);
  return h ? `\n⚠️ ตรงกับวันหยุด: ${h.name}` : dow === 0 || dow === 6 ? '\n⚠️ ตรงกับวันเสาร์-อาทิตย์' : '';
};

function createJob(rt, cmd) {
  const j = cmd.job || {};
  if (!j.title) return reply(rt, 'ขาดชื่องาน');
  const due = isValidYmd(j.due_date) ? j.due_date : null;
  const id = db.prepare('INSERT INTO jobs(title,customer,due_date,note) VALUES(?,?,?,?)')
    .run(j.title, cmd.customer?.name ?? null, due, j.note ?? null).lastInsertRowid;
  return reply(rt, `เพิ่มงาน #${id}: ${j.title}\nกำหนดส่ง: ${due ? thaiDate(due, true) + dateWarn(due) : 'ยังไม่ระบุ'}`);
}

function updateJob(rt, cmd) {
  const j = cmd.job || {};
  if (!j.ref) return reply(rt, 'ระบุเลขงานหรือชื่องาน เช่น "งาน #3 เสร็จแล้ว"');
  const m = String(j.ref).match(/^#?(\d+)$/);
  const found = m
    ? db.prepare('SELECT * FROM jobs WHERE id=?').all(Number(m[1]))
    : db.prepare(`SELECT * FROM jobs WHERE ${OPEN} AND (title LIKE ? OR customer LIKE ?)`).all(`%${j.ref}%`, `%${j.ref}%`);
  if (!found.length) return reply(rt, 'ไม่พบงานที่ตรงกัน');
  if (found.length > 1) return reply(rt, 'พบหลายงาน ระบุเลขงาน:\n' + found.map((x) => `#${x.id} ${x.title}`).join('\n'));
  const job = found[0];
  const due = isValidYmd(j.due_date) ? j.due_date : job.due_date;
  const status = j.status || job.status;
  db.prepare("UPDATE jobs SET status=?, due_date=?, note=COALESCE(?,note), updated_at=CURRENT_TIMESTAMP WHERE id=?")
    .run(status, due, j.note ?? null, job.id);
  db.prepare('INSERT INTO job_events(job_id,text) VALUES(?,?)').run(job.id, [status !== job.status && `สถานะ → ${status}`, j.note].filter(Boolean).join(' | ') || 'อัปเดต');
  return reply(rt, `อัปเดตงาน #${job.id} ${job.title}\nสถานะ: ${status}\nกำหนดส่ง: ${due ? thaiDate(due, true) + dateWarn(due) : '-'}`);
}

function jobList(upTo) {
  const today = todayBkk();
  const rows = db.prepare(`SELECT * FROM jobs WHERE ${OPEN} ${upTo ? 'AND due_date IS NOT NULL AND due_date<=?' : ''} ORDER BY due_date IS NULL, due_date`)
    .all(...(upTo ? [upTo] : []));
  if (!rows.length) return upTo ? '' : 'ไม่มีงานค้าง 🎉';
  return `งาน (${thaiDate(today, true)})\n` + rows.map((r) => {
    const tag = !r.due_date ? '' : r.due_date < today ? ' ❗เลยกำหนด' : r.due_date === today ? ' ⏰วันนี้' : '';
    return `#${r.id} ${r.title} [${r.status}] ${r.due_date ? thaiDate(r.due_date) : 'ไม่มีกำหนด'}${tag}`;
  }).join('\n');
}

// แจ้งเตือนทุกเช้า 08:00 เวลาไทย: งานเลยกำหนด/ครบวันนี้/ครบพรุ่งนี้
cron.schedule('0 8 * * *', async () => {
  const msg = jobList(addDays(todayBkk(), 1));
  if (msg) for (const u of ALLOWED) await push(u, '🔔 ' + msg);
}, { timezone: 'Asia/Bangkok' });

// ---------- เว็บ: ดูเอกสาร + หลังบ้านง่ายๆ ----------
app.get('/d/:token', (req, res) => {
  const row = db.prepare('SELECT * FROM documents WHERE token=?').get(req.params.token);
  return row ? res.send(renderDoc(row)) : res.sendStatus(404);
});

app.get('/admin', (req, res) => {
  const [, b64] = (req.get('authorization') || '').split(' ');
  const pass = Buffer.from(b64 || '', 'base64').toString().split(':').slice(1).join(':');
  if (!process.env.ADMIN_PASSWORD || pass !== process.env.ADMIN_PASSWORD) {
    res.set('WWW-Authenticate', 'Basic realm="admin"'); return res.sendStatus(401);
  }
  const docs = db.prepare('SELECT * FROM documents ORDER BY id DESC LIMIT 50').all();
  const jobs = db.prepare(`SELECT * FROM jobs WHERE ${OPEN} ORDER BY due_date IS NULL, due_date`).all();
  res.send(`<!doctype html><meta charset="utf-8"><body style="font-family:sans-serif">
<h2>เอกสารล่าสุด</h2><table border="1" cellpadding="6">${docs.map((d) =>
    `<tr><td><a href="/d/${d.token}">${esc(d.doc_no)}</a></td><td>${esc(TYPES[d.type].title)}</td><td>${esc(JSON.parse(d.customer).name)}</td><td>${fmtBaht(d.total)}</td><td>${esc(d.status)}</td></tr>`).join('')}</table>
<h2>งานค้าง</h2><table border="1" cellpadding="6">${jobs.map((j) =>
    `<tr><td>#${j.id}</td><td>${esc(j.title)}</td><td>${esc(j.status)}</td><td>${j.due_date ? thaiDate(j.due_date) : '-'}</td></tr>`).join('')}</table></body>`);
});

app.listen(process.env.PORT || 3000, () => console.log('running'));

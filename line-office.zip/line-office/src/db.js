import Database from 'better-sqlite3';

export const db = new Database(process.env.DB_PATH || 'data.db');
db.pragma('journal_mode = WAL');

// เงินเก็บเป็น "สตางค์" (จำนวนเต็ม) เพื่อเลี่ยงปัญหาทศนิยม
db.exec(`
CREATE TABLE IF NOT EXISTS documents (
  id INTEGER PRIMARY KEY,
  type TEXT NOT NULL,
  doc_no TEXT UNIQUE NOT NULL,
  token TEXT UNIQUE NOT NULL,
  issue_date TEXT NOT NULL,            -- YYYY-MM-DD (เวลาไทย)
  customer TEXT NOT NULL,              -- JSON
  items TEXT NOT NULL,                 -- JSON (หน่วยสตางค์)
  discount INTEGER DEFAULT 0,
  vat_mode TEXT NOT NULL,
  subtotal INTEGER, vat INTEGER, total INTEGER,
  note TEXT, payment_terms TEXT, ref_doc_no TEXT,
  status TEXT DEFAULT 'issued',        -- issued | void (ห้ามลบเอกสารภาษี ให้ยกเลิกแทน)
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS counters (key TEXT PRIMARY KEY, n INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS jobs (
  id INTEGER PRIMARY KEY,
  title TEXT NOT NULL, customer TEXT, doc_no TEXT,
  status TEXT DEFAULT 'รอดำเนินการ',
  due_date TEXT, note TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS job_events (
  id INTEGER PRIMARY KEY, job_id INTEGER NOT NULL, text TEXT NOT NULL,
  at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS pending (
  user_id TEXT PRIMARY KEY, payload TEXT NOT NULL, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS holidays (date TEXT PRIMARY KEY, name TEXT);  -- กรอกเองทุกปีตามประกาศ
`);

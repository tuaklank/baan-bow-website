import crypto from 'node:crypto';
import { db } from './db.js';
import { ddmmyyBE } from './thai.js';

export const TYPES = {
  quotation:           { prefix: 'QT', title: 'ใบเสนอราคา', tax: false },
  receipt:             { prefix: 'RC', title: 'ใบเสร็จรับเงิน', tax: false },
  tax_invoice:         { prefix: 'TI', title: 'ใบกำกับภาษี', tax: true },
  receipt_tax_invoice: { prefix: 'RT', title: 'ใบเสร็จรับเงิน/ใบกำกับภาษี', tax: true },
};

const sat = (x) => Math.round(Number(x) * 100);

/** คำนวณยอดด้วยโค้ดเสมอ (ไม่ให้ AI คิดเลข) */
export function compute({ items, discount, vat_mode }) {
  const lines = items.map((i) => {
    const qty = Number(i.qty) || 1;
    const unit = sat(i.unit_price);
    return { name: String(i.name), unit_price: unit, qty, amount: Math.round(unit * qty) };
  });
  const subtotal = lines.reduce((a, l) => a + l.amount, 0);
  const disc = sat(discount || 0);
  const after = subtotal - disc;
  let vat = 0, total = after;
  if (vat_mode === 'exclusive') { vat = Math.round(after * 0.07); total = after + vat; }
  if (vat_mode === 'inclusive') { vat = after - Math.round(after / 1.07); }
  return { lines, subtotal, discount: disc, vat, total };
}

/** เลขที่เอกสาร: คำนำหน้า + ddmmyy(พ.ศ.) + เลขรัน 3 หลัก (รันใหม่ทุกวันต่อประเภท) */
const nextNo = db.transaction((type, ymd) => {
  const key = `${type}:${ymd}`;
  const { n } = db.prepare(
    `INSERT INTO counters(key,n) VALUES(?,1) ON CONFLICT(key) DO UPDATE SET n=n+1 RETURNING n`
  ).get(key);
  return `${TYPES[type].prefix}${ddmmyyBE(ymd)}${String(n).padStart(3, '0')}`;
});

export function insertDoc(d) {
  const tx = db.transaction(() => {
    const doc_no = nextNo(d.type, d.issue_date);
    const token = crypto.randomBytes(16).toString('hex');
    db.prepare(`INSERT INTO documents
      (type,doc_no,token,issue_date,customer,items,discount,vat_mode,subtotal,vat,total,note,payment_terms,ref_doc_no)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(
      d.type, doc_no, token, d.issue_date, JSON.stringify(d.customer), JSON.stringify(d.items),
      d.discount, d.vat_mode, d.subtotal, d.vat, d.total, d.note ?? null, d.payment_terms ?? null, d.ref_doc_no ?? null);
    return db.prepare('SELECT * FROM documents WHERE doc_no=?').get(doc_no);
  });
  return tx();
}

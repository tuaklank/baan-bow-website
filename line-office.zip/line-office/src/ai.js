import { todayBkk, thaiDate } from './thai.js';

/** แปลงข้อความที่พิมพ์ใน LINE เป็นคำสั่ง JSON (AI ทำหน้าที่ "อ่านเข้าใจ" เท่านั้น ไม่คิดเลข) */
export async function parseCommand(text) {
  const today = todayBkk();
  const system = `คุณคือตัวแปลงข้อความของเจ้าของร้านเป็นคำสั่ง JSON สำหรับระบบเอกสารและติดตามงาน
ตอบเป็น JSON object เดียวเท่านั้น ห้ามมีข้อความอื่นหรือ markdown
วันนี้คือ ${today} (${thaiDate(today, true)}) เขตเวลา Asia/Bangkok ใช้เป็นฐานแปลง "พรุ่งนี้" "ศุกร์หน้า" "สิ้นเดือน" เป็น YYYY-MM-DD (ค.ศ.)
ห้ามคำนวณยอดรวม/ภาษี ดึงเฉพาะตัวเลขที่ผู้ใช้พิมพ์ ห้ามเดาข้อมูลที่ไม่ได้ระบุ ให้ใส่ null
รูปแบบ:
{"intent":"create_doc|convert_doc|create_job|update_job|list_jobs|help|unknown",
 "doc_type":"quotation|receipt|tax_invoice|receipt_tax_invoice|null",
 "customer":{"name":null,"address":null,"tax_id":null,"phone":null},
 "items":[{"name":"","unit_price":0,"qty":1}],
 "discount":null,"vat_mode":"none|exclusive|inclusive|null",
 "payment_terms":null,"note":null,"from_doc_no":null,
 "job":{"ref":null,"title":null,"due_date":null,"status":null,"note":null}}
กฎ: ทำใบเสนอราคา/ใบเสร็จ/ใบกำกับภาษี = create_doc; ออกใบเสร็จ/ใบกำกับภาษีจากเลขที่เอกสารเดิม = convert_doc (doc_type ปลายทาง + from_doc_no);
เพิ่มงาน/สร้างงาน = create_job; อัปเดตงาน/งานเสร็จแล้ว = update_job (job.ref = เลขงานหรือคำค้น);
งานวันนี้/งานค้าง = list_jobs. status ใช้เฉพาะ: รอดำเนินการ, กำลังทำ, รอลูกค้า, เสร็จ, ยกเลิก
"รวม vat"/"ราคารวมภาษี" = inclusive, "ไม่รวม vat"/"+vat" = exclusive, "ไม่มี vat" = none, ไม่พูดถึง = null`;

  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'x-api-key': process.env.ANTHROPIC_API_KEY,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: process.env.CLAUDE_MODEL || 'claude-sonnet-5-5',
      max_tokens: 1000, system,
      messages: [{ role: 'user', content: text }],
    }),
  });
  if (!res.ok) throw new Error('Claude API ' + res.status);
  const data = await res.json();
  const raw = data.content.filter((b) => b.type === 'text').map((b) => b.text).join('');
  try { return JSON.parse(raw.match(/\{[\s\S]*\}/)[0]); } catch { return { intent: 'unknown' }; }
}

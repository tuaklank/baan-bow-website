import crypto from 'node:crypto';

export function verifySignature(rawBody, signature) {
  const mac = crypto.createHmac('sha256', process.env.LINE_CHANNEL_SECRET).update(rawBody).digest('base64');
  const a = Buffer.from(signature || ''), b = Buffer.from(mac);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

const call = (path, body) => fetch('https://api.line.me/v2/bot/message/' + path, {
  method: 'POST',
  headers: { 'content-type': 'application/json', authorization: 'Bearer ' + process.env.LINE_CHANNEL_ACCESS_TOKEN },
  body: JSON.stringify(body),
});

// LINE จำกัดข้อความละ 5,000 ตัวอักษร
export const reply = (replyToken, text) => call('reply', { replyToken, messages: [{ type: 'text', text: text.slice(0, 4900) }] });
export const push = (to, text) => call('push', { to, messages: [{ type: 'text', text: text.slice(0, 4900) }] });

const TZ = 'Asia/Bangkok';
const MONTHS = ['มกราคม','กุมภาพันธ์','มีนาคม','เมษายน','พฤษภาคม','มิถุนายน','กรกฎาคม','สิงหาคม','กันยายน','ตุลาคม','พฤศจิกายน','ธันวาคม'];
const DAYS = ['อาทิตย์','จันทร์','อังคาร','พุธ','พฤหัสบดี','ศุกร์','เสาร์'];

/** วันนี้ตามเวลาไทย เป็น YYYY-MM-DD (ไม่ขึ้นกับเวลาของเซิร์ฟเวอร์) */
export const todayBkk = () => new Intl.DateTimeFormat('en-CA', { timeZone: TZ }).format(new Date());

export const isValidYmd = (s) =>
  typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) &&
  new Date(s + 'T00:00:00Z').toISOString().slice(0, 10) === s;

export function addDays(ymd, n) {
  const d = new Date(ymd + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}

export const dayOfWeek = (ymd) => new Date(ymd + 'T00:00:00Z').getUTCDay();

/** 2026-10-18 -> "วันอาทิตย์ที่ 18 ตุลาคม 2569" */
export function thaiDate(ymd, withDay = false) {
  const [y, m, d] = ymd.split('-').map(Number);
  return `${withDay ? `วัน${DAYS[dayOfWeek(ymd)]}ที่ ` : ''}${d} ${MONTHS[m - 1]} ${y + 543}`;
}

/** 2026-10-18 -> "181069" (ddmmyy พ.ศ.) */
export function ddmmyyBE(ymd) {
  const [y, m, d] = ymd.split('-').map(Number);
  return String(d).padStart(2, '0') + String(m).padStart(2, '0') + String((y + 543) % 100).padStart(2, '0');
}

export const fmtBaht = (satang) =>
  (satang / 100).toLocaleString('th-TH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

// ---------- จำนวนเงินเป็นตัวอักษรไทย ----------
const D = ['ศูนย์','หนึ่ง','สอง','สาม','สี่','ห้า','หก','เจ็ด','แปด','เก้า'];
const P = ['', 'สิบ', 'ร้อย', 'พัน', 'หมื่น', 'แสน'];

function chunk(s) { // s ยาวไม่เกิน 6 หลัก
  let out = '';
  const len = s.length;
  for (let i = 0; i < len; i++) {
    const d = +s[i], pos = len - i - 1;
    if (d === 0) continue;
    if (pos === 1) out += (d === 1 ? '' : d === 2 ? 'ยี่' : D[d]) + 'สิบ';
    else if (pos === 0) out += d === 1 && len > 1 ? 'เอ็ด' : D[d];
    else out += D[d] + P[pos];
  }
  return out;
}
function readInt(s) {
  s = s.replace(/^0+/, '');
  if (!s) return 'ศูนย์';
  if (s.length > 6) return readInt(s.slice(0, -6)) + 'ล้าน' + chunk(s.slice(-6));
  return chunk(s);
}
export function bahtText(satang) {
  const baht = Math.floor(satang / 100), st = satang % 100;
  let out = readInt(String(baht)) + 'บาท';
  out += st ? readInt(String(st)) + 'สตางค์' : 'ถ้วน';
  return out;
}

import { TYPES } from './docs.js';
import { thaiDate, fmtBaht, bahtText } from './thai.js';

export const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

export function renderDoc(row) {
  const t = TYPES[row.type];
  const c = JSON.parse(row.customer);
  const items = JSON.parse(row.items);
  const e = process.env;
  const base = row.total - row.vat;
  const rows = items.map((l, i) => `<tr><td class="c">${i + 1}</td><td>${esc(l.name)}</td>
    <td class="r">${fmtBaht(l.unit_price)}</td><td class="c">${l.qty}</td><td class="r">${fmtBaht(l.amount)}</td></tr>`).join('');
  const sum = (label, v) => `<tr><td colspan="4" class="r">${label}</td><td class="r">${fmtBaht(v)}</td></tr>`;
  const vatRows = row.vat_mode === 'none' ? '' :
    sum('ภาษีมูลค่าเพิ่ม 7%', row.vat);
  return `<!doctype html><html lang="th"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(t.title)} ${esc(row.doc_no)}</title>
<link href="https://fonts.googleapis.com/css2?family=Sarabun:wght@400;700&display=swap" rel="stylesheet">
<style>
body{font-family:'Sarabun',sans-serif;max-width:800px;margin:24px auto;padding:0 16px;color:#111}
h1{text-align:center;margin:8px 0}.head{display:flex;justify-content:space-between;gap:16px}
table{width:100%;border-collapse:collapse;margin-top:12px}td,th{border:1px solid #444;padding:6px 8px}
th{background:#eee}.r{text-align:right}.c{text-align:center}.box{border:1px solid #444;padding:8px;margin-top:12px}
.sign{display:flex;justify-content:space-around;margin-top:56px;text-align:center}
.void{color:#c00;font-weight:700;text-align:center}
@media print{.noprint{display:none}body{margin:0}}
</style></head><body>
<button class="noprint" onclick="print()">พิมพ์ / บันทึกเป็น PDF</button>
${row.status === 'void' ? '<p class="void">** ยกเลิกเอกสาร **</p>' : ''}
<div class="head"><div><b>${esc(e.SELLER_NAME)}</b><br>${esc(e.SELLER_ADDRESS)}<br>
${t.tax ? `เลขประจำตัวผู้เสียภาษี ${esc(e.SELLER_TAX_ID)} (${esc(e.SELLER_BRANCH)})<br>` : ''}โทร ${esc(e.SELLER_PHONE)}</div>
<div class="r">เลขที่ ${esc(row.doc_no)}<br>วันที่ ${thaiDate(row.issue_date)}${row.ref_doc_no ? `<br>อ้างอิง ${esc(row.ref_doc_no)}` : ''}</div></div>
<h1>${esc(t.title)}</h1>
<div class="box">ลูกค้า: ${esc(c.name)}<br>ที่อยู่: ${esc(c.address)}<br>
เลขประจำตัวผู้เสียภาษี: ${esc(c.tax_id)} &nbsp; โทร: ${esc(c.phone)}</div>
<table><tr><th>ลำดับ</th><th>รายการ</th><th>ราคาต่อหน่วย</th><th>จำนวน</th><th>จำนวนเงิน</th></tr>${rows}
${row.discount ? sum('ส่วนลด', -row.discount) : ''}
${row.vat_mode !== 'none' ? sum('มูลค่าก่อนภาษี', base) : ''}${vatRows}
<tr><td colspan="4" class="r"><b>รวมทั้งสิ้น</b></td><td class="r"><b>${fmtBaht(row.total)}</b></td></tr></table>
<p>(${bahtText(row.total)})</p>
${row.payment_terms ? `<p>เงื่อนไขการชำระเงิน: ${esc(row.payment_terms)}</p>` : ''}
${row.note ? `<p>หมายเหตุ: ${esc(row.note)}</p>` : ''}
<div class="sign"><div>______________________<br>${row.type === 'quotation' ? 'ผู้เสนอราคา' : 'ผู้รับเงิน'}</div>
<div>______________________<br>${row.type === 'quotation' ? 'ผู้อนุมัติ' : 'ผู้จ่ายเงิน'}</div></div>
</body></html>`;
}
